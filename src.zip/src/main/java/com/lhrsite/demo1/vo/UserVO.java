package com.lhrsite.demo1.vo;


import lombok.Data;

@Data
public class UserVO {
    private Integer id;
    private String userName;
    private String nickName;
    private Integer sex;
}
